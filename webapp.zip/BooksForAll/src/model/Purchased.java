package model;
/**
 * 
 * @author rabeea ashqar
 *Purchased book , 
 *the book Id , the user name 
 *of the person who purchased the book  
 *and the current page the user has reached 
 */

public class Purchased {

	String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public Purchased() {
		super();
	}
	public Purchased(String id, String userName, double currentPage) {
		super();
		this.id = id;
		this.userName = userName;
		this.currentPage = currentPage;
	}
	public Purchased(String id,  double currentPage) {
		super();
		this.id = id;
		this.userName = "";
		this.currentPage =currentPage;
	}
	
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public double getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(double currentPage) {
		this.currentPage = currentPage;
	}
	String userName;
	double currentPage;
}
