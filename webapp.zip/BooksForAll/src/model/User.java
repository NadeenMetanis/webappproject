package model;
/**
 * 
 * @author rabeea ashqar
 *the user Object , 
 * with the right attributes 
 */
public class User {

	private String username;
	private String email;
	private String address;
	private String tel;
	private String password;
	private String nickname;
	private String description;
	private String photo;

	public User(String user,String pass){
		this.username=user;
		this.password=pass;
	}

	public User(String username,String email,String address,String tel,String password, String nickname,String description,String photo){
		this.username=username;
		this.email=email;
		this.address=address;
		this.tel=tel;
		this.password=password;
		this.nickname=nickname;
		this.description=description;
		this.photo=photo;
	}
	public User(String username){
		this.username=username;
		this.email="";
		this.address="";
		this.tel="";
		this.password="";
		this.nickname="";
		this.description="";
		this.photo="";
	}
	
	/*
	public User(String user,String mail,String addr,String tel,String pass, String nick,String Desc,String pic){
		this.Username=user;
		this.Email=mail;
		this.Address=addr;
		this.Phone=tel;
		this.Password=pass;
		this.Nickname=nick;
		this.Description=Desc;
		this.Photo=pic;
	}
	*/

	public User() {
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	
	
}
