package model;
/**
 * 
 * @author rabeea ashqar
 *
 *the Review object, 
 *the string review content , and 
 *the id of the right book 
 */
public class Review {

	String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	String rev;
	public String getRev() {
		return rev;
	}
	public void setRev(String rev) {
		this.rev = rev;
	} 
	
	public Review() {
		
	}
	public Review(String id1,String rev1) {
		this.id=id1;
		this.rev=rev1;
	}
}
