package model;

/**
 * 
 * @author rabeea ashqar
 *id : The id of the book 
 *name : the name of the book 
 *Image : a cover photo 
 *a short description of the book 
 *price : the price a user should pay to purchase to book 
 *the number of people who liked the book 
 *url to the specific html file with contains the book 
 *
 */
public class EBook {

	private String id;
	private String 	name;
	private String image;
	private String price;
	
	private String description;
	private int likes;
	private String url;

	public EBook(String id) {
		this.id=id;
		this.name="";
		this.price="";
		this.description="";
		this.likes=7;
		this.image="";
		this.url="";
	}
	
	public EBook(String id,String name,String image, String price ,String description ,int likes,String url) {
		this.id=id;
		this.name=name;
		this.price=price;
		this.description=description;
		this.likes=likes;
		this.image=image;
		this.url=url;
	}


	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	

	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getPrice() {
		return price;
	}



	public void setPrice(String price) {
		this.price = price;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public int getLikes() {
		return likes;
	}



	public void setLikes(int likes) {
		this.likes = likes;
	}


}
