package model;

/**
 * 
 * @author rabeea ashqar
 *
 *the class of Liker object, 
 *which contains the name of the person who Liked a book ,
 *and the id of the book that was liked 
 */

public class Liker {

	
	String name; 
	String bookid;

	public Liker(){ }
	public Liker(String na,String id){
		this.name=na;
		this.bookid=id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBookid() {
		return bookid;
	}
	public void setBookid(String bookid) {
		this.bookid = bookid;
	}


}
