package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import constants.appConstants;
import model.EBook;
import model.Review;

/**
 * Servlet implementation class addReviewServlet
 * in this servlet we receive the review from the User, Who already purchased the 
 * book, and would like to add a review , so we get the review and add it to the 
 * reviews database 
 */
@WebServlet("/addReviewServlet")
public class addReviewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addReviewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine =null;
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String Json = jsonFileContent.toString();
		Gson gson = new GsonBuilder().create();
  
		Review review=gson.fromJson(Json,Review.class);

	try {	
		 Context context = new InitialContext();
	  		BasicDataSource ds = (BasicDataSource)context.lookup(
	  				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
	  		Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement(appConstants.ADD_REVIEW);// (id,rev)
			stmt.setString(1,review.getId());			
			stmt.setString(2,review.getRev());			
			stmt.executeUpdate();
			
			stmt.close();
			conn.close();
			
	}
	catch (NamingException | SQLException e) {

		e.printStackTrace();
	}
		
	}

}
