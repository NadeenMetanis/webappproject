package servlets;
	
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import constants.appConstants;
import model.EBook;

/**
 * Servlet implementation class MyEBooks
 * 
 * This servlet get an id (String) for user in Json format 
 * from the client, and returns (from database) a list of the books 
 * that user has purchased 
 * to be able to read them , like and review ! 
 * 
 */
@WebServlet("/MyEBooks")
public class MyEBooks extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyEBooks() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine =null;
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String Json = jsonFileContent.toString();
		Gson gson = new GsonBuilder().create();
	/*	EBook temp1 = gson.fromJson(Json, EBook.class);
		EBook temp =new EBook(Json);

		String id = temp.getId();
		  System.out.println(id);*/


		// check (by book id) if this username already liked the book  
		
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("userName"); // we get the name of the user to add it to the likers 
	
		if (userName==null) {
			 response.setContentType("application/json");
		      PrintWriter out = response.getWriter();

		    out.println("NOTLOGGED");
				out.close();
		}
		else if(userName=="admin") {
			 response.setContentType("application/json");
		      PrintWriter out = response.getWriter();

		    out.println("admin");
				out.close();
		}
		ArrayList<EBook> books=new ArrayList<EBook>();
		books=getEBooks(userName);


					String bo=gson.toJson(books);
				//	System.out.println(bo);
					
					 response.setContentType("application/json");
				      PrintWriter out = response.getWriter();
				      
						String JsonBooks = gson.toJson(books, new TypeToken<ArrayList<EBook>>() {
						}.getType());

						//   out.println(message);
				    out.println(JsonBooks);
						out.close();
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
			
		

	}
	
	public ArrayList<EBook> getEBooks(String username){
	
		ArrayList<EBook> mybooks = new ArrayList<EBook>();

		try {
		Context context = new InitialContext();
  		BasicDataSource ds = (BasicDataSource)context.lookup(
  				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
  		Connection conn = ds.getConnection();
/*			PreparedStatement stmt = conn.prepareStatement(appConstants.SELECT_BOUGHT_STMT);
		
			stmt.setString(1, username);

			ResultSet rs=stmt.executeQuery(); */
  		
  		PreparedStatement stmt = conn.prepareStatement(appConstants.SELECT_PURCHASED_STMT);
		
		stmt.setString(1, username);

		ResultSet rs=stmt.executeQuery();
  		
			String id="";
			while(rs.next()) {
				
			//	String price=String.valueOf(rs.getDouble(3));
			//	String likes=String.valueOf(rs.getInt(5));

			//System.out.println(rs.getString(1)+"44");
			id=(rs.getString(1));
			

			
			
			stmt = conn.prepareStatement(appConstants.SELECT_EBOOK_BY_NAME_STMT);
			stmt.setString(1, id);
			ResultSet rs2=stmt.executeQuery();
			while(rs2.next()) {
				
				mybooks.add(new EBook(rs2.getString(1),rs2.getString(2),rs2.getString(3),rs2.getString(4),rs2.getString(5),rs2.getInt(6),rs2.getString(7)));


			}
			}
			
			rs.close();
			stmt.close();
			conn.close();
		
		}
	catch (NamingException | SQLException e) {

		e.printStackTrace();
	}
		//System.out.println(books);

		return mybooks;
	}
}