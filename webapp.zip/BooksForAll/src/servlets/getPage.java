package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import constants.appConstants;
import model.EBook;
import model.Purchased;

/**
 * Servlet implementation class getPage
 */
@WebServlet("/getPage")
public class getPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine =null;
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String Json = jsonFileContent.toString();
		Gson gson = new GsonBuilder().create();
		//String id3 = gson.fromJson(Json, String.class);
		Purchased temp=gson.fromJson(Json,Purchased.class);
		//String id=temp.getId();
	
		HttpSession session = request.getSession();
		String userName=(String) session.getAttribute("userName");
		
		HttpSession session2 = request.getSession();
		String id=(String) session2.getAttribute("id");
		
		try {
			Context context = new InitialContext();
	  		BasicDataSource ds = (BasicDataSource)context.lookup(
	  				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
	  		Connection conn = ds.getConnection();
	  		
	  		String pageNum="";
				PreparedStatement stmt = conn.prepareStatement(appConstants.GET_PAGE);// (id,rev)
					
				stmt.setString(1,id);
				stmt.setString(2,userName);

				ResultSet rs=stmt.executeQuery();
				if(rs.next()){
				 pageNum=rs.getString(1);
				
				}
				response.setContentType("application/json");
				PrintWriter out = response.getWriter();
				      
				out.println(gson.toJson(pageNum));
				out.close();
				stmt.close();
				conn.close();
				
		}
		catch (NamingException | SQLException e) {

			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
