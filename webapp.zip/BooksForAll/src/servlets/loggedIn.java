package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

/**
 * Servlet implementation class loggedIn
 * this servlet returns  the name of the Signed in user , 
 * using Session , 
 * to know if this is a normal user, admin , or he didn't sign in yet 
 */
@WebServlet("/loggedIn")
public class loggedIn extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loggedIn() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Gson gson=new Gson();
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("userName"); // we get the name of the user to add it to the likers 
		String user=" " ; 
		if(userName.equals("admin"))
			user="admin";
		else if (userName.equals(""))
			user="NOTLOGGED";
		else
			user="user";
		
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		      
		out.println(gson.toJson(user));
		out.close();			
			
		}			

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}
}

