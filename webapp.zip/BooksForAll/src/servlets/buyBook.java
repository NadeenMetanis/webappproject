package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import constants.appConstants;
import model.EBook;


/**
 * Servlet implementation class buyBook
 * after confirmation, in this servlet we add the purchased book 
 * to the right database, and add the book to the user's EBooks.
 */
@WebServlet("/buyBook")
public class buyBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public buyBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine =null;
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String Json = jsonFileContent.toString();
		Gson gson = new GsonBuilder().create();
		//String id3 = gson.fromJson(Json, String.class);
		EBook temp=gson.fromJson(Json,EBook.class);

		String id = temp.getId();
		//  System.out.println(id);
		 double currentPage=0; 

		// check (by book id) if this username already liked the book  
		
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("userName"); // we get the name of the user to add it to the likers 
		
		
		
		if (userName==null) {
			 response.setContentType("application/json");
		      PrintWriter out = response.getWriter();

		    out.println("NOTLOGGED");
				out.close();
		}
		else if(userName=="admin") {
			 response.setContentType("application/json");
		      PrintWriter out = response.getWriter();

		    out.println("admin");
				out.close();
		}
		
		//String userName1 ="rabeea";
		try {
	/*	 Context context = new InitialContext();
	  		BasicDataSource ds = (BasicDataSource)context.lookup(
	  				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
	  		Connection conn = ds.getConnection();
	  		
	  		PreparedStatement stmt = conn.prepareStatement(appConstants.BUY_BOOK);
			stmt.setString(1,id);
			stmt.setString(2,userName);
			stmt.executeUpdate();

			stmt.close(); */
			 Context context = new InitialContext();
		  		BasicDataSource ds = (BasicDataSource)context.lookup(
		  				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
		  		Connection conn = ds.getConnection();
		  		
		  		PreparedStatement stmt = conn.prepareStatement(appConstants.PURCHASE_BOOK);
				stmt.setString(1,id);
				stmt.setString(2,userName);
				stmt.setDouble(3,currentPage);
				stmt.executeUpdate();

				stmt.close();
		   
			String result = "SUCCESS";
			response.setContentType("application/json");
		    PrintWriter out = response.getWriter();
		      
		   //   out.println(message);
		   // System.out.println(result +"fff" +(gson.toJson(result)));
		    out.println(gson.toJson(result));
				out.close();
				
	  		
	  		
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	  		
		
	}

}
