package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import constants.appConstants;
import model.EBook;
import model.User;

/**
 * Servlet implementation class browseUsers
 * this servlet we receive a command from the Client,
 * to get all the users from the users dataBase 
 * and send them back in JSON format  
 */
@WebServlet("/browseUsers")
public class browseUsers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public browseUsers() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		ArrayList<User> Users=new ArrayList<User>();
		Users=getUsers();
		Gson gson= new Gson();
			//String books = null;
		// get the username of the current user 
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("userName");

					String bo=gson.toJson(Users);
					System.out.println(bo);
					
					 response.setContentType("application/json");
				      PrintWriter out = response.getWriter();
				      
						String JsonBooks = gson.toJson(Users, new TypeToken<ArrayList<EBook>>() {
						}.getType());

						//   out.println(message);
				    out.println(JsonBooks);
						out.close();
	}

	public ArrayList<User> getUsers(){
		
		ArrayList<User> Users = new ArrayList<User>();

		try {
		Context context = new InitialContext();
  		BasicDataSource ds = (BasicDataSource)context.lookup(
  				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
  		Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement(appConstants.SELECT_ALL_USERS_STMT);	
			ResultSet rs=stmt.executeQuery();
			while(rs.next()) {
				
			//	String price=String.valueOf(rs.getDouble(3));
			//	String likes=String.valueOf(rs.getInt(5));

			//	System.out.println(rs.getString(1)+"44"+rs.getString(3));
				Users.add(new User(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8)));

			}
			
			
			rs.close();
			stmt.close();
			conn.close();
		
		}
	catch (NamingException | SQLException e) {

		e.printStackTrace();
	}
		//System.out.println(books);

		return Users;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
