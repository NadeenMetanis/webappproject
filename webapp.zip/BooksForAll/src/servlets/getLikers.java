package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import constants.appConstants;
import model.EBook;
import model.Liker;
import model.Review;

/**
 * Servlet implementation class getLikers
 * Here we return a list of likers , who liked 
 * a specific book, by receiving it's id
 */
@WebServlet("/getLikers")
public class getLikers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getLikers() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	//	String revs=getReviewsById(request.getParameter("Id")) ; // get the reviews by the bookName
	
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine =null;
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String Json = jsonFileContent.toString();
		Gson gson = new GsonBuilder().create();
		EBook id=gson.fromJson(Json,EBook.class);
		ArrayList<Liker> Likers=getLikersById(id.getId()); // get the reviews by the id

		
		Gson gs=new Gson();
		String like =gs.toJson(Likers);



	//	System.out.println(rev+"999");
			
		    response.setContentType("application/json");
		      PrintWriter out = response.getWriter();
		      
		   //   out.println(message);
		    out.println(like);
		    out.close();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);


	}

	
	
	public ArrayList<Liker> getLikersById(String Id) {
		ArrayList<Liker> likeArr=new ArrayList<Liker>();
		String like = "";
		try {
			Context context = new InitialContext();

			BasicDataSource ds = (BasicDataSource)context.lookup(
	  				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
	  		Connection conn = ds.getConnection();
				PreparedStatement stmt = conn.prepareStatement(appConstants.SELECT_LIKERS_STMT);	
			
				stmt.setString(1, Id);	 // receive the books Id , to return the reviews for that book 		
				ResultSet rs=stmt.executeQuery();
				//r.setId(Id);
				while(rs.next()) {
					Liker r=new Liker();
					r.setBookid(Id);
					like=rs.getString(1);
						r.setName(like);			
						likeArr.add(r);
						/*if(rs.getString(1) !="null")
							revs="Review: " + rs.getString(1);
							rev2.add( revs);*/
				}	
				//System.out.println(likeArr);
				stmt.close();
				conn.close();
			/*	
			    response.setContentType("application/json");
			      PrintWriter out = response.getWriter();
			      
			   //   out.println(message);
			    out.println(gson.toJson(revs));
					out.close();*/
					
			}
			catch (NamingException | SQLException e) {

				e.printStackTrace();
			}	
			return likeArr;
		
	}
}