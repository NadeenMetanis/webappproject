package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import constants.appConstants;
import model.EBook;
import model.User;

/**
 * Servlet implementation class LikeServlet
 * 
 * this servlet updates the right dataBases when the user likes a book 
 * he already purchased 
 * so we add his name to the likers database , with the id 
 * of the book he liked , 
 * and we update the number of likes for that book 
 */
@WebServlet("/LikeServlet")
public class LikeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LikeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("resource")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		
		// get the id of the book in JSON format 
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine =null;
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String Json = jsonFileContent.toString();
		Gson gson = new GsonBuilder().create();
		//EBook temp = gson.fromJson(Json, EBook.class);
		EBook temp =new EBook(Json);

		String id = temp.getId();
		 // System.out.println(id);


		// check (by book id) if this username already liked the book  
		
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("userName"); // we get the name of the user to add it to the likers 

		try {
		Context context = new InitialContext();
		BasicDataSource ds = (BasicDataSource)context.lookup(
  				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
  		Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement(appConstants.CHECK_LIKER);	
		
			stmt.setString(1,id);	 // receive the books id 
			stmt.setString(2, userName);
			ResultSet rs=stmt.executeQuery();
			int likeSum=0;
			
			String likeBtn="like"; 
			while(rs.next()) {
			//	System.out.println(rs.getString(1));
				likeBtn="unlike";
			}
			 
			// SHOULD SEND exist/not
			String result="";

			stmt = conn.prepareStatement(appConstants.SELECT_LIKES_STMT); // by bookId
				stmt.setString(1,id);	 // recieve the books id 
				ResultSet res=stmt.executeQuery();
				if(res.next()){
			//	System.out.println(res.getString(0));
				if(res.getString(1) != null)
				
				
					likeSum=res.getInt(6);
				if(likeBtn.equals("like")) 		{
					likeSum++;
					result="NotExist";
					stmt = conn.prepareStatement(appConstants.ADD_LIKER);
					stmt.setString(1,userName);	 // receive the books id 
					stmt.setString(2, id);
					stmt.executeUpdate();

				}
				else {
					likeSum--;
					result="Exist";
					stmt = conn.prepareStatement(appConstants.REMOVE_LIKER);
					stmt.setString(1,userName);	 // receive the books id 
					stmt.setString(2, id);
					stmt.executeUpdate();

				}
				
				}
			stmt = conn.prepareStatement(appConstants.UPDATE_LIKES);
			
			stmt.setInt(1,likeSum);	 // 
			stmt.setString(2,id);	 // recieve the books name 		
			stmt.executeUpdate();
			
			// UPDATE LIKERS of that book 
		
		
			
			
		    response.setContentType("application/json");
		    PrintWriter out = response.getWriter();
		      
		   //   out.println(message);
		    out.println(gson.toJson(result));
				out.close();
				
		}
		catch (NamingException | SQLException e) {

			e.printStackTrace();
		}
		
	
	}

}
