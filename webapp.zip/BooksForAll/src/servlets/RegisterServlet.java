package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import constants.appConstants;
import model.User;

/**
 * Servlet implementation class RegisterServlet
 * 
 * here we get the values of the parameters of the user 
 * who is registering, and we add this user to the dataBase , 
 * and return a success message to the client 
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**9
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String message = null;
		//		System.out.println("request");
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine =null;
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String Json = jsonFileContent.toString();
		Gson gson = new GsonBuilder().create();
		User temp = gson.fromJson(Json, User.class);
		
	//	System.out.println( temp.getEmail()+ " aa "+temp.getPassword()+ "vv " );
	//	ArrayList<String> msgArray = new ArrayList<String>();

		
		  String userName = temp.getUsername();
		  String Email = temp.getEmail();
		  String Address = temp.getAddress();
		  String Tel = temp.getTel();
		  String Password = temp.getPassword();
		  String Nickname =temp.getNickname() ;
		  String Description =temp.getDescription();		
		  String Photo =temp.getPhoto();
	/*	System.out.println( request.getParameter("#Email")+"11");
		System.out.println( request.getParameter("Email")+"22");
		System.out.println( request.getParameter("email"));
		  String userName = request.getParameter("username");
		  String Email = request.getParameter("email");
		  String Address = request.getParameter("address");
		  String Tel = request.getParameter("tel");
		  String Password = request.getParameter("password");
		  String Nickname = request.getParameter("nickname");
		  String Description = request.getParameter("description");		
		  String Photo = request.getParameter("photo");*/

	   

	      
	      
	    	  try {
	  			if(userExsist(userName)){
	  				  message="NotAvailable";
	  		    //	 out.println(gson.toJson(message));
	  		    	//  out.println(gson);
	  			  /*    out.println("{");
	  		        out.println("\"data\": \"NotAvailable\"");/
	  		       
	  		        out.println("}");*/
	  		        
	  				//out.close();
	  			  }
	  		} catch (NamingException | SQLException e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	      if(InsertUser(userName,Email,Address,Tel,Password,Nickname,Description,Photo)){
		    	  message="SUCCESS";
	    	// out.println(gson.toJson(message));
	    	/*  out.println(gson);
	    	    /* out.println("{");
	  		        out.println("\"data\": \"SUCCESS\"");
	  		       
	  		        out.println("}");
	    	  out.close();*/
	      }
	      else {
	    	message="NotAvailable";
	      	/*out.println(gson.toJson(message));
	    	out.println(gson);
			out.close();*/
	      }
	      // SESSION  STARTS
	      HttpSession session = request.getSession(true);
			session.setAttribute("userName", userName);
		// SESSION  END
			
	      response.setContentType("application/json");
	      PrintWriter out = response.getWriter();
	      
	   //   out.println(message);
	    out.println(gson.toJson(message));
			out.close();
	      
	// System.out.println(message+ " r ");
	      
	}
	      //PrintWriter o = response.getWriter();
	      //o.println("sadasd");
	  	
  	/*	String userJsonResult = null;
  		PrintWriter writer = response.getWriter();

  		if (message.equals("FAIL"))
  			jsonResult="NotAvailable";
  		else
  			jsonResult="SUCCESS";
  	  res.println(gson.toJson(jsonResult));
  	  
  		
  		
		writer.println(userJsonResult);
      	writer.close();
      	out.close();
      	*/
	    
	 
	
		 /*
		  * UserExsist checks if thi username already used 
		  * by another user .
		  */
		  public boolean userExsist(String username)throws  NamingException, SQLException{
				Context context = new InitialContext();
	    		BasicDataSource ds = (BasicDataSource)context.lookup(
	    				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
	    		Connection conn = ds.getConnection();
	    		
				PreparedStatement stmt = conn.prepareStatement("SELECT * FROM USERS WHERE userName=?");
				stmt.setString(1,username);			

				ResultSet res=stmt.executeQuery();
				if(res.next()) // username found
				{
					stmt.close();
					conn.close();
					return true; 
				}
				return false;
			  
		  }
			public boolean InsertUser(String username, String email,String address,String phone,String password, String nickname, String description, String photo) {
				try{
					//obtain CustomerDB data source from Tomcat's context
		    	
					
					Context context = new InitialContext();
		    		BasicDataSource ds = (BasicDataSource)context.lookup(
		    				getServletContext().getInitParameter(appConstants.DB_DATASOURCE) + appConstants.OPEN);
		    		Connection conn = ds.getConnection();
					String insertSql = "INSERT INTO USERS VALUES(?,?,?,?,?,?,?,?)";
					
					PreparedStatement stmt = conn.prepareStatement(insertSql);
					stmt.setString(1, username);
					stmt.setString(2, email);
					stmt.setString(3, address);
					stmt.setString(4, phone);
					stmt.setString(5, password);
					stmt.setString(6, nickname);
					stmt.setString(7, description);
					stmt.setString(8, photo);

					
					stmt.executeUpdate();
					conn.close();
					stmt.close();
					return true;
		    	
		    		
		    		
		    		
				}catch (SQLException | NamingException e) {
					getServletContext().log("Error", e);
				}
				
				return false;

			}
		
			public boolean validEmail(String mail){
				
				if(!(mail.contains("@"))||!(mail.contains(".")))
					return false;
				return true;
				
			}
			public boolean validPhone(String sPhoneNumber) {
				
				      Pattern pattern = Pattern.compile("\\d{10}");
				      Matcher matcher = pattern.matcher(sPhoneNumber);

				      if (matcher.matches())
				    	  return true ; 
				      return false ; 
				     
				 }
			
			
			public boolean validAddress(String address){
				 Pattern pattern = Pattern.compile("\\d{7}");
			      Matcher matcher = pattern.matcher(address);

			      if (matcher.matches())
			    	  return true ; 
			      return false ; 
			     
			 }
			}
