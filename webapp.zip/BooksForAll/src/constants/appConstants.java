package constants;

import java.lang.reflect.Type;
import java.util.Collection;

import com.google.gson.reflect.TypeToken;

import model.EBook;
import model.User;

public interface appConstants {
	
	
	public final String USERS = "users";
	public final String USERS_FILE = USERS + ".json";
	public final String NAME = "name";
	public final Type USER_COLLECTION = new TypeToken<Collection<User>>() {}.getType();
	//derby constants
	public final String DB_NAME = "DB_NAME";
	public final String DB_DATASOURCE = "DB_DATASOURCE";
	public final String PROTOCOL = "jdbc:derby:"; 
	public final String OPEN = "Open";
	public final String SHUTDOWN = "Shutdown";
	
	// CREATE A TABLE FOR BOOKNAME,REVIEWS
	public final String CREATE_REVIEWS_TABLE="CREATE TABLE REVIEWS (Id  varchar(100) ,"
			+"Review varchar(1000)) ";
	public final String ADD_REVIEW="INSERT INTO REVIEWS (Id,Review) VALUES(?,?)";
	
	public final String REVIEWS = "Reviews";
	public final String REVIEWS_FILE = REVIEWS + ".json";

	public final String SELECT_REVIEWS = "SELECT Review FROM REVIEWS WHERE Id=?";
	public final String DELETE_REVIEW="DELETE FROM REVIEWS WHERE (Id=? AND Review=?)";
	// CREATE A TABLE FOR BOOKNAME,LIKERS
	public final String CREATE_LIKERS_TABLE="CREATE TABLE LIKERS (Id  varchar(100),"
			+"Liker varchar(100) )";
	public final String ADD_LIKER ="INSERT INTO LIKERS (Liker,Id) VALUES(?,?)";
	public final String REMOVE_LIKER ="DELETE FROM LIKERS WHERE (Liker=? AND Id=?)";

	public final String SELECT_LIKERS_STMT = "SELECT Liker FROM LIKERS WHERE Id=?";
	public final String CHECK_LIKER = "SELECT Liker FROM LIKERS WHERE Id=? AND Liker=?";
	
	// EBOOK DATABASE
	
	public final String CREATE_EBOOKS_TABLE = "CREATE TABLE EBOOKS(Id varchar(100) PRIMARY KEY ,"
			+ "Name varchar(400),"
			+ "Image varchar(400),"
			+ "Price varchar(100),"
			+ "Description varchar(400),"
			+ "Likes integer ,"
			+ "url varchar(400))";

	public final String BROWSE_ALL_BOOKS="SELECT * FROM EBOOKS";
	public final String SELECT_EBOOK_BY_NAME_STMT = "SELECT * FROM EBOOKS WHERE Id=?";
	public final String SELECT_LIKES_STMT = "SELECT * FROM EBOOKS WHERE Id=?";
	public final String UPDATE_LIKES="UPDATE EBOOKS SET Likes=? WHERE Id=?";
	
	
// creatE purchase bookS table 
	public final String CREATE_PURCHASED_TABLE = "CREATE TABLE PURCHASED(Id varchar(100) ,"
			+" userName varchar(100),"
			+" currentPage DOUBLE)";
	public final String PURCHASE_BOOK ="INSERT INTO PURCHASED (Id,userName,currentPage) VALUES(?,?,?)";
	public final String SELECT_PURCHASED_STMT = "SELECT * FROM PURCHASED WHERE userName=?";
	public final String UPDATE_PAGE="UPDATE PURCHASED SET currentPage=? WHERE Id=? AND userName=?";
	public final String GET_PAGE="SELECT currentPage FROM PURCHASED WHERE Id=? AND userName=?";
	
	// creatE BOUGHT bookS table 	
	public final String CREATE_BOUGHT_TABLE = "CREATE TABLE BOUGHT(Id varchar(100) ,"
		+" userName varchar(100))"; 
	public final String BUY_BOOK ="INSERT INTO BOUGHT (Id,userName) VALUES(?,?)";
	public final String SELECT_BOUGHT_STMT = "SELECT * FROM BOUGHT WHERE userName=?";
	
//END BOUGHT 
	public final String INSERT_EBOOK_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes,url) VALUES(?,?,?,?,?,?,?)";
	public final String EBOOKS = "EBooks";
	public final String EBOOKS_FILE = EBOOKS + ".json";
	public final Type EBOOKS_COLLECTION = new TypeToken<Collection<EBook>>() {}.getType();

	
	
/*	
	public final String INSERT_BOOK1_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes,url) VALUES('56630','Rome, by W. Warde Fowler_ a Project Gutenberg eBook','/WebProject/WebContent/Rome, by W. Warde Fowler_ a Project Gutenberg eBook_files/cover.jpg','69.99$','des',0,'/WebProject/WebContent/Rome, by W. Warde Fowler_ a Project Gutenberg eBook.html')";
	public final String INSERT_BOOK2_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes) VALUES('56632','Distributed Proofreader's Canada eBook of Two Little Women and Treasure House','/WebProject/WebContent/Distributed Proofreader's Canada eBook of Two Little Women and Treasure House_files/cover.jpg','60.00$','des',0,'/WebProject/WebContent/Distributed Proofreader's Canada eBook of Two Little Women and Treasure House.html')";
	public final String INSERT_BOOK3_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes) VALUES('56636','The Project Gutenberg eBook of Kárpáthy Zoltán by Mór Jókai','/WebProject/WebContent/The Project Gutenberg eBook of Kárpáthy Zoltán by Mór Jókai_files/cover.jpg','45.00$','des',0,'/WebProject/WebContent/The Project Gutenberg eBook of Kárpáthy Zoltán by Mór Jókai.html')";
	public final String INSERT_BOOK4_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes) VALUES('76','HUCKLEBERRY FINN, By Mark Twain, Complete','/WebProject/WebContent/HUCKLEBERRY FINN, By Mark Twain, Complete_files/bookcover.jpg','36.00$','des',0,'/WebProject/WebContent/HUCKLEBERRY FINN, By Mark Twain, Complete.html')";
	public final String INSERT_BOOK5_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes) VALUES('56625','SONGS OF THE WEST','/WebProject/WebContent/Songs of the West, by Sabine Baring-Gould. A Project Gutenberg eBook._files/cover.jpg','80.00$','des',0,'/WebProject/WebContent/Songs of the West, by Sabine Baring-Gould. A Project Gutenberg eBook..html')";
	public final String INSERT_BOOK6_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes) VALUES('56620','The Project Gutenberg eBook of Ruby Roland, the Girl Spy, by Frederick Whittaker','\"/WebProject/WebContent/The Project Gutenberg eBook of Ruby Roland, the Girl Spy, by Frederick Whittaker._files/cover.jpg','64.00$','des',0,'/WebProject/WebContent/The Project Gutenberg eBook of Ruby Roland, the Girl Spy, by Frederick Whittaker..html')";
	public final String INSERT_BOOK7_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes) VALUES('56628','The Project Gutenberg eBook of An Essay on Colophons with specimens and translations, by Alfred W. Pollard','/WebProject/WebContent/The Project Gutenberg eBook of An Essay on Colophons with specimens and translations, by Alfred W. Pollard._files/caxtonclub-cover.jpg','46.00$','des',0,'/WebProject/WebContent/The Project Gutenberg eBook of An Essay on Colophons with specimens and translations, by Alfred W. Pollard..html')";
	public final String INSERT_BOOK8_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes) VALUES('56614','Village Folk-Tales of Ceylon, Volume 1 (of 3) by Henry Parker','','4.4$','des',0,'/WebProject/WebContent/Village Folk-Tales of Ceylon; Volume I.html')";
	public final String INSERT_BOOK9_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes) VALUES ('56617','The Art of Theatrical Make-up by Cavendish Morton','ima','4.4$','des',5)";

	public final String INSERT_BOOK10_STMT = "INSERT INTO EBOOKS (Id,Name,Image,Price,Description,Likes) VALUES('56618','The Friends of Voltaire by S. G. Tallentyre','ima','4.4$','des',5)";
	*/
	
	// USER DATABASE
	public final String CREATE_USERS_TABLE = "CREATE TABLE USERS(userName varchar(100) PRIMARY KEY ,"
			+ "Email varchar(100) UNIQUE NOT NULL,"
			+ "Address varchar(100),"
			+ "Phone varchar(10) ,"
			+ "Password varchar(10) ,"
			+ "Nickname varchar(100)  UNIQUE NOT NULL,"
			+ "Description varchar(100),"
			+ "photo varchar(100))";

	public final String INSERT_ADMIN_STMT = "INSERT INTO USERS (userName,Email,Address,Phone,Password,Nickname,Description,photo)"+
			" VALUES('admin','admin','admin','0500000000','Passw0rd','admin','admin','admin')";
	public final String DELETE_USER="DELETE FROM USERS WHERE userName=?";
	public final String INSERT_USER_STMT = "INSERT INTO USERS VALUES(?,?,?,?,?,?,?,?)";
	public final String SELECT_ALL_USERS_STMT = "SELECT * FROM USERS";
	public final String SELECT_USER_BY_USERNAME_STMT = "SELECT * FROM USERS WHERE userName=?";
	

}
