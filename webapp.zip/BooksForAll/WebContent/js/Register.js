$(document).ready(function() {
		$("#Register").click(function() {
			$.ajax({
				type : 'POST',
				url : "http://localhost:8080/BooksForAll/RegisterServlet",
				data : {
					username : $("#Name").val(),
					email : $("Email").val(),
					address : $("Address").val(),
					tel : $("Telephone").val(),
					password : $("#Password").val(),
					nickname : $("#Nickname").val(),
					description : $("#Description").val(),
					photo : $("#URL").val(),
				}
			}).done(function(data) {
				  var parsed = $.parseJSON(data);
				  $.each(parsed, function (i, jsondata) {
				      if(jsondata.message == "FAIL"){
				    	  alert("User name not available!");
				    	  
				      }else if (jsondata.message == "SUCCESS"){
				    	  alert("Successfully Registered!");
				    	  window.location = "main.html";
				      }else{
				    	  alert("Please fill in all required fields")
				    	  
				      }
				     
				  });
			});

		});

	});