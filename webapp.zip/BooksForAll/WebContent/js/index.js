function load() {

  document.getElementById("UserName").focus();
 }

 $(document).ready(function() {
  $("#Login").click(function() {
   $.ajax({
    type : "POST",
    url : "http://localhost:8080/WebProject/loginServlet",
    data : {
     username : $("#UserName").val(),
     password : $("#Password").val()
    }
   }).done(function(data) {
     
       var parsed = $.parseJSON(data);
       $.each(parsed, function (i, jsondata) {
           if(jsondata.message == "NOT_FOUND"){
            alert("User name doesnt exist, Please try again!");
            
           }else if (jsondata.message == "WRONG_PASSWORD"){
            alert("User name or password are wrong, Please try again!");
           }else{
            alert("Successfully logged in!")
            window.location = "homepage.html";
           }
          
       });
       
      
    
   });
  });
 });