

$scope.contRead=function(){
	$scope.lastPage=$(window).scrollTop();
}
